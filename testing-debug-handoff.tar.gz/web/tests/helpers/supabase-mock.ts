/* eslint-disable @typescript-eslint/no-explicit-any */
import type { Database } from '@/types/supabase';

type Tables = keyof Database['public']['Tables'];
type RowOf<T extends Tables> = Database['public']['Tables'][T]['Row'];

type Filter =
  | { type: 'eq' | 'neq'; column: string; value: any }
  | { type: 'in'; column: string; values: any[] };

type OrderBy = { column: string; options?: { ascending?: boolean; nullsFirst?: boolean } };

export type QueryOp = 'select' | 'insert' | 'update' | 'delete' | 'rpc';

export interface QueryState {
  table?: Tables;
  op?: QueryOp;
  selects?: string;
  filters: Filter[];
  orderBy?: OrderBy[];
  range?: { from: number; to: number };
  limit?: number;
  data?: any;          // for insert/update payloads
  throwOnError?: boolean;
  rpc?: { fn: string; args?: Record<string, any> };
}

type PostgrestError = { message: string; code?: string; details?: any; hint?: string };
type PostgrestResponse<T> = { data: T | null; error: PostgrestError | null };

export const okSingle = <T>(row: T): PostgrestResponse<T> => ({ data: row as any, error: null });
export const okList = <T>(rows: T[]): PostgrestResponse<T[]> => ({ data: rows as any, error: null });
export const err = (message: string, code = '400'): PostgrestResponse<any> => ({ data: null, error: { message, code } });

/** cross-env test double creator */
function makeFn<T extends (...args: any[]) => any>() {
  const viLike = (globalThis as any).vi?.fn?.bind((globalThis as any).vi);
  const jestLike = (globalThis as any).jest?.fn?.bind((globalThis as any).jest);
  return (viLike ?? jestLike ?? ((impl?: any) => {
    const f: any = (...args: any[]) => {
      f.mock.calls.push(args);
      return impl ? impl(...args) : undefined;
    };
    f.mock = { calls: [] as any[], results: [] as any[], implementations: [] as any[] };
    f.mockImplementation = (impl2: any) => { impl = impl2; return f; };
    f.mockResolvedValue = (v: any) => f.mockImplementation(async () => v);
    f.mockResolvedValueOnce = (v: any) => {
      const prev = impl;
      let used = false;
      f.mockImplementation(async (...a: any[]) => {
        f.mock.calls.push(a);
        if (!used) { used = true; return v; }
        return prev ? prev(...a) : undefined;
      });
      return f;
    };
    f.mockClear = () => { f.mock.calls = []; f.mock.results = []; f.mock.implementations = []; };
    return f;
  }))();
}

/** deep-ish clone for state snapshots */
const clone = <T,>(v: T): T => (typeof structuredClone === 'function' ? structuredClone(v) : JSON.parse(JSON.stringify(v)));

export type Handles = {
  single: ReturnType<typeof makeFn>;         // (state: QueryState) => Promise<PostgrestResponse<any>>
  maybeSingle: ReturnType<typeof makeFn>;
  list: ReturnType<typeof makeFn>;
  mutate: ReturnType<typeof makeFn>;         // for insert/update/delete
  rpc: ReturnType<typeof makeFn>;            // for client.rpc()

  // internal hooks for DSL (kept public for convenience)
  _pushAssertion: (op: QueryOp, predicate: (s: QueryState) => any, desc: string) => void;
  _popAssertion: (op: QueryOp) => ((s: QueryState) => any) | undefined;
};

export type Metrics = {
  counts: Record<'single' | 'maybeSingle' | 'list' | 'mutate' | 'rpc', number>;
  byTable: Record<string, Partial<Record<'single' | 'maybeSingle' | 'list' | 'mutate' | 'rpc', number>>>;
};

export function makeMockSupabase() {
  const initialState: QueryState = { filters: [] };
  const assertions: Record<QueryOp, Array<{ test: (s: QueryState) => any; desc: string }>> = {
    select: [], insert: [], update: [], delete: [], rpc: [],
  };

  const metrics: Metrics = {
    counts: { single: 0, maybeSingle: 0, list: 0, mutate: 0, rpc: 0 },
    byTable: {},
  };

  const bump = (table: string | undefined, key: keyof Metrics['counts']) => {
    metrics.counts[key] += 1;
    if (!table) return;
    metrics.byTable[table] ||= {};
    metrics.byTable[table][key] = (metrics.byTable[table][key] ?? 0) + 1;
  };

  const handles: Handles = {
    single: makeFn(),
    maybeSingle: makeFn(),
    list: makeFn(),
    mutate: makeFn(),
    rpc: makeFn(),
    _pushAssertion(op, predicate, desc) { assertions[op].push({ test: predicate, desc }); },
    _popAssertion(op) { return assertions[op].shift()?.test; },
  };

  function assertIfNeeded(op: QueryOp, state: QueryState) {
    const a = assertions[op][0]; // peek; don't shift unless it matches
    if (!a) return;
    const passed = !!a.test(state);
    if (passed) assertions[op].shift();
    else {
      const pretty = JSON.stringify(state, null, 2);
      throw new Error(
        `when() expectation did not match for op="${op}".\nExpected: ${a.desc}\nActual state: ${pretty}`
      );
    }
  }

  function builder<T extends Tables>(state: QueryState & { table: T }) {
    const api = {
      select(cols?: string) {
        state = { ...state, op: 'select', selects: cols ?? '*' };
        return api;
      },
      insert(payload: Partial<RowOf<T>> | Partial<RowOf<T>>[]) {
        state = { ...state, op: 'insert', data: payload };
        return api;
      },
      update(payload: Partial<RowOf<T>>) {
        state = { ...state, op: 'update', data: payload };
        return api;
      },
      delete() {
        state = { ...state, op: 'delete' };
        return api;
      },
      eq(column: string, value: any) {
        state = { ...state, filters: [...state.filters, { type: 'eq', column, value }] };
        return api;
      },
      neq(column: string, value: any) {
        state = { ...state, filters: [...state.filters, { type: 'neq', column, value }] };
        return api;
      },
      in(column: string, values: any[]) {
        state = { ...state, filters: [...state.filters, { type: 'in', column, values }] };
        return api;
      },
      order(column: string, options?: { ascending?: boolean; nullsFirst?: boolean }) {
        state = { ...state, orderBy: [...(state.orderBy ?? []), { column, options }] };
        return api;
      },
      range(from: number, to: number) {
        state = { ...state, range: { from, to } };
        return api;
      },
      limit(n: number) {
        state = { ...state, limit: n };
        return api;
      },
      throwOnError() {
        state = { ...state, throwOnError: true };
        return api;
      },

      async single(): Promise<PostgrestResponse<RowOf<T>>> {
        bump(state.table, 'single');
        assertIfNeeded('select', state);
        const out = await handles.single(clone(state));
        if (state.throwOnError && out.error) throw Object.assign(new Error(out.error.message), out.error);
        return out;
      },

      async maybeSingle(): Promise<PostgrestResponse<RowOf<T> | null>> {
        bump(state.table, 'maybeSingle');
        assertIfNeeded('select', state);
        const out = await handles.maybeSingle(clone(state));
        if (state.throwOnError && out.error) throw Object.assign(new Error(out.error.message), out.error);
        return out;
      },

      async list(): Promise<PostgrestResponse<RowOf<T>[]>> {
        const op = state.op === 'select' ? 'list' : 'mutate';
        bump(state.table, op as any);
        assertIfNeeded(state.op ?? 'select', state);
        const call = state.op === 'select' ? handles.list : handles.mutate;
        const out = await call(clone(state));
        if (state.throwOnError && out.error) throw Object.assign(new Error(out.error.message), out.error);
        return out;
      },
    };
    return api;
  }

  const client = {
    from<T extends Tables>(table: T) {
      return builder<T>({ ...clone(initialState), table });
    },
    // RPC support
    async rpc<T = any>(fn: string, args?: Record<string, any>): Promise<PostgrestResponse<T>> {
      const state: QueryState = { ...clone(initialState), op: 'rpc', rpc: { fn, args } };
      bump(undefined, 'rpc');
      assertIfNeeded('rpc', state);
      const out = await handles.rpc(clone(state));
      return out;
    },
  };

  const getMetrics = () => clone(metrics);
  const resetMetrics = () => {
    metrics.counts = { single: 0, maybeSingle: 0, list: 0, mutate: 0, rpc: 0 };
    metrics.byTable = {};
  };

  return { client, handles, getMetrics, resetMetrics };
}

export type MockSupabase = ReturnType<typeof makeMockSupabase>;
