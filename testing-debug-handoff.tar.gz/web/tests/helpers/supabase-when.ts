/* eslint-disable @typescript-eslint/no-explicit-any */
import type { Handles, QueryState, QueryOp, PostgrestResponse } from './supabase-mock';
import { okList, okSingle, err } from './supabase-mock';

type Tables = QueryState['table'];

type MatcherState = Partial<Pick<QueryState, 'table' | 'op' | 'selects' | 'filters' | 'orderBy' | 'range' | 'limit'>>;

const matches = (expected: MatcherState, actual: QueryState) => {
  if (expected.table && expected.table !== actual.table) return false;
  if (expected.op && expected.op !== actual.op) return false;

  // Selects (string equality for simplicity)
  if (typeof expected.selects === 'string' && expected.selects !== actual.selects) return false;

  // Filters (subset match)
  if (expected.filters) {
    const ok = expected.filters.every(exp =>
      actual.filters.some(act => JSON.stringify(act) === JSON.stringify(exp))
    );
    if (!ok) return false;
  }

  // orderBy / range / limit: if provided, require exact equality
  for (const key of ['orderBy', 'range', 'limit'] as const) {
    if (expected[key] && JSON.stringify(expected[key]) !== JSON.stringify((actual as any)[key])) return false;
  }

  return true;
};

export function when(handles: Handles) {
  let draft: MatcherState = {};

  const api = {
    table(table: Tables) { draft.table = table; return api; },
    op(op: QueryOp) { draft.op = op; return api; },
    select(cols: string) { draft.selects = cols; draft.op ||= 'select'; return api; },
    eq(column: string, value: any) {
      draft.filters = [...(draft.filters ?? []), { type: 'eq', column, value }];
      return api;
    },
    neq(column: string, value: any) {
      draft.filters = [...(draft.filters ?? []), { type: 'neq', column, value }];
      return api;
    },
    in(column: string, values: any[]) {
      draft.filters = [...(draft.filters ?? []), { type: 'in', column, values }];
      return api;
    },
    order(column: string, options?: { ascending?: boolean; nullsFirst?: boolean }) {
      draft.orderBy = [...(draft.orderBy ?? []), { column, options }];
      return api;
    },
    range(from: number, to: number) { draft.range = { from, to }; return api; }
    ,
    limit(n: number) { draft.limit = n; return api; },

    // ---- responders ---------------------------------------------------------
    returnsSingle<T>(row: T) {
      handles._pushAssertion('select', s => matches(draft, s), describe('returnsSingle'));
      handles.single.mockResolvedValueOnce(okSingle(row));
      draft = {};
      return api;
    },

    returnsMaybeSingle<T>(row: T | null) {
      handles._pushAssertion('select', s => matches(draft, s), describe('returnsMaybeSingle'));
      handles.maybeSingle.mockResolvedValueOnce({ data: row as any, error: null });
      draft = {};
      return api;
    },

    returnsList<T>(rows: T[]) {
      const op = (draft.op ?? 'select');
      handles._pushAssertion(op, s => matches(draft, s), describe('returnsList'));
      (op === 'select' ? handles.list : handles.mutate).mockResolvedValueOnce(okList(rows));
      draft = {};
      return api;
    },

    returnsError(message: string, code = '400') {
      const op = (draft.op ?? 'select');
      handles._pushAssertion(op, s => matches(draft, s), describe('returnsError'));
      const resp: PostgrestResponse<any> = { data: null, error: { message, code } };
      const target = op === 'select' ? [handles.single, handles.maybeSingle, handles.list] : [handles.mutate];
      for (const t of target) t.mockResolvedValueOnce(resp);
      draft = {};
      return api;
    },

    // RPC path
    rpc(fn: string, args?: Record<string, any>) {
      draft = { ...draft, op: 'rpc' };
      handles._pushAssertion('rpc', (s) => s.rpc?.fn === fn && JSON.stringify(s.rpc?.args ?? {}) === JSON.stringify(args ?? {}), `rpc(${fn})`);
      return {
        returns<T>(data: T) { handles.rpc.mockResolvedValueOnce({ data, error: null }); },
        returnsError(message: string, code = '400') { handles.rpc.mockResolvedValueOnce({ data: null, error: { message, code } }); },
      };
    },
  };

  function describe(label: string) {
    return `${label}: ${JSON.stringify(draft)}`;
  }

  return api;
}

// -------- Assertions helpers -----------------------------------------------

export function expectQueryState(
  mockFn: { mock: { calls: any[][] } },
  subset: Partial<QueryState>
) {
  const last = mockFn.mock.calls.at(-1)?.[0] as QueryState | undefined;
  if (!last) throw new Error('No calls recorded on this mock.');
  const ok = Object.entries(subset).every(([k, v]) => JSON.stringify((last as any)[k]) === JSON.stringify(v));
  if (!ok) {
    throw new Error(`QueryState mismatch.\nExpected subset: ${JSON.stringify(subset, null, 2)}\nActual last: ${JSON.stringify(last, null, 2)}`);
  }
}

export function expectExactQueryState(
  mockFn: { mock: { calls: any[][] } },
  exact: QueryState
) {
  const last = mockFn.mock.calls.at(-1)?.[0] as QueryState | undefined;
  if (!last) throw new Error('No calls recorded on this mock.');
  const ok = JSON.stringify(last) === JSON.stringify(exact);
  if (!ok) {
    throw new Error(`Exact QueryState mismatch.\nExpected: ${JSON.stringify(exact, null, 2)}\nActual : ${JSON.stringify(last, null, 2)}`);
  }
}

export function expectNoDBCalls(handles: Handles) {
  const total =
    handles.single.mock.calls.length +
    handles.maybeSingle.mock.calls.length +
    handles.list.mock.calls.length +
    handles.mutate.mock.calls.length +
    handles.rpc.mock.calls.length;
  if (total !== 0) throw new Error(`Expected no DB calls, but recorded ${total}.`);
}

export function expectOnlyTablesCalled(handles: Handles, tables: string[]) {
  const gather = (calls: any[][]) => calls.map(c => (c?.[0]?.table)).filter(Boolean);
  const used = new Set([
    ...gather(handles.single.mock.calls),
    ...gather(handles.maybeSingle.mock.calls),
    ...gather(handles.list.mock.calls),
    ...gather(handles.mutate.mock.calls),
  ]);
  for (const t of used) {
    if (!tables.includes(String(t))) {
      throw new Error(`Unexpected table used: "${t}". Allowed: ${tables.join(', ')}`);
    }
  }
}


