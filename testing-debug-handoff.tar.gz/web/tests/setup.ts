import { afterEach } from '@jest/globals';
import { resetAllMocks } from './helpers/reset-mocks';
import { makeMockSupabase } from './helpers/supabase-mock';

let ms: ReturnType<typeof makeMockSupabase> | null = null;

export const getMS = () => {
  if (!ms) {
    ms = makeMockSupabase();
  }
  return ms;
};

afterEach(() => {
  if (ms) {
    resetAllMocks(ms.handles);
    ms.resetMetrics();
  }
});


