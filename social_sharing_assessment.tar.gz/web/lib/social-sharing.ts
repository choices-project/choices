/**
 * Social Sharing Utilities for Choices
 * 
 * This module provides utilities for creating viral, activist-themed social shares
 * that position Choices as a "social app with suspiciously activist undertones"
 */

export interface SocialShareData {
  title: string
  description: string
  url: string
  imageUrl?: string
  hashtags?: string[]
  callToAction?: string
}

export interface PollShareData extends SocialShareData {
  pollId: string
  totalVotes: number
  isActive: boolean
  options: string[]
  participationRate: number
}

export interface CivicsShareData extends SocialShareData {
  representativeName: string
  office: string
  level: 'federal' | 'state' | 'local'
  party?: string
  jurisdiction: string
}

// Activist-themed messaging templates
export const ACTIVIST_MESSAGES = {
  poll: {
    viral: [
      "🔥 This poll is breaking the internet! What's your take?",
      "💭 They don't want you to see this poll. But here it is.",
      "🗳️ Your voice matters. This poll proves it.",
      "⚡ This poll is changing minds. Will it change yours?",
      "🎯 The establishment is watching this poll. Vote anyway.",
      "🚀 This poll is going viral for a reason. Join the conversation.",
      "💡 This poll reveals what people really think. Shocking results.",
      "🔥 Hot take: This poll exposes the real issues. What do you think?",
      "⚡ This poll is making waves. Don't miss out on the debate.",
      "🎯 They're talking about this poll everywhere. Now it's your turn."
    ],
    engagement: [
      "Your vote could change everything. What's your choice?",
      "This poll is heating up. Where do you stand?",
      "The results are surprising everyone. Cast your vote!",
      "This poll is sparking real conversations. Join in!",
      "Your opinion matters here. Make it count!",
      "This poll is getting attention for a reason. Vote now!",
      "The debate is intense. What's your position?",
      "This poll is revealing the truth. Don't stay silent!",
      "Your voice is needed here. Cast your vote!",
      "This poll is making history. Be part of it!"
    ]
  },
  civics: {
    representative: [
      "🏛️ Meet your representative: {name}. Know them?",
      "🗳️ Your voice reaches {name}. Make it count.",
      "⚖️ {name} represents YOU. How well do you know them?",
      "🏛️ {name} is making decisions for you. Stay informed.",
      "🗳️ Your representative {name} needs to hear from you.",
      "⚖️ {name} is in office because of voters like you.",
      "🏛️ {name} represents {jurisdiction}. Know their stance?",
      "🗳️ {name} is your voice in {office}. Make it loud.",
      "⚖️ {name} is accountable to YOU. Hold them to it.",
      "🏛️ {name} is making policy that affects you. Stay engaged."
    ],
    engagement: [
      "Knowledge is power. Know your representatives.",
      "Your representatives work for YOU. Stay informed.",
      "Democracy works when you participate. Start here.",
      "Your voice matters in government. Make it heard.",
      "Representation starts with knowledge. Get informed.",
      "Your representatives need your input. Give it to them.",
      "Democracy is a conversation. Join the discussion.",
      "Your representatives are listening. Speak up.",
      "Knowledge of your representatives is your right.",
      "Your voice in government starts with knowing who represents you."
    ]
  }
}

// Social platform configurations
export const SOCIAL_PLATFORMS = {
  twitter: {
    name: 'Twitter/X',
    color: '#1DA1F2',
    icon: '🐦',
    maxLength: 280,
    hashtagLimit: 3
  },
  facebook: {
    name: 'Facebook',
    color: '#1877F2',
    icon: '📘',
    maxLength: 63206,
    hashtagLimit: 10
  },
  linkedin: {
    name: 'LinkedIn',
    color: '#0077B5',
    icon: '💼',
    maxLength: 3000,
    hashtagLimit: 5
  },
  instagram: {
    name: 'Instagram',
    color: '#E4405F',
    icon: '📷',
    maxLength: 2200,
    hashtagLimit: 30
  },
  tiktok: {
    name: 'TikTok',
    color: '#000000',
    icon: '🎵',
    maxLength: 300,
    hashtagLimit: 5
  }
}

// Generate viral poll share content
export function generatePollShareContent(poll: PollShareData): SocialShareData {
  const viralMessage = ACTIVIST_MESSAGES.poll.viral[
    Math.floor(Math.random() * ACTIVIST_MESSAGES.poll.viral.length)
  ]
  
  const engagementMessage = ACTIVIST_MESSAGES.poll.engagement[
    Math.floor(Math.random() * ACTIVIST_MESSAGES.poll.engagement.length)
  ]
  
  const hashtags = [
    '#ChoicesApp',
    '#YourVoiceMatters',
    '#DemocracyInAction',
    '#VoteNow',
    '#PollViral'
  ]
  
  const statusEmoji = poll.isActive ? '🟢' : '🔴'
  const voteCount = poll.totalVotes > 0 ? `${poll.totalVotes} votes` : 'New poll'
  const participation = poll.participationRate > 0 ? `${Math.round(poll.participationRate)}% participation` : ''
  
  const title = `${statusEmoji} ${poll.title}`
  const description = `${viralMessage}\n\n${engagementMessage}\n\n${voteCount}${participation ? ` • ${participation}` : ''}`
  
  return {
    title,
    description,
    url: poll.url,
    hashtags,
    callToAction: poll.isActive ? 'Vote now!' : 'View results!'
  }
}

// Generate civics representative share content
export function generateCivicsShareContent(rep: CivicsShareData): SocialShareData {
  const viralMessage = ACTIVIST_MESSAGES.civics.representative[
    Math.floor(Math.random() * ACTIVIST_MESSAGES.civics.representative.length)
  ].replace('{name}', rep.representativeName)
   .replace('{office}', rep.office)
   .replace('{jurisdiction}', rep.jurisdiction)
  
  const engagementMessage = ACTIVIST_MESSAGES.civics.engagement[
    Math.floor(Math.random() * ACTIVIST_MESSAGES.civics.engagement.length)
  ]
  
  const hashtags = [
    '#ChoicesApp',
    '#KnowYourReps',
    '#CivicEngagement',
    '#DemocracyInAction',
    '#StayInformed'
  ]
  
  if (rep.party) {
    hashtags.push(`#${rep.party}`)
  }
  
  const levelEmoji = {
    federal: '🏛️',
    state: '🏛️',
    local: '🏛️'
  }[rep.level]
  
  const title = `${levelEmoji} ${rep.representativeName} - ${rep.office}`
  const description = `${viralMessage}\n\n${engagementMessage}`
  
  return {
    title,
    description,
    url: rep.url,
    hashtags,
    callToAction: 'Learn more about your representatives!'
  }
}

// Generate social media URLs
export function generateSocialUrls(shareData: SocialShareData, platform: keyof typeof SOCIAL_PLATFORMS): string {
  const { title, description, url, hashtags } = shareData
  const platformConfig = SOCIAL_PLATFORMS[platform]
  
  const hashtagString = hashtags?.slice(0, platformConfig.hashtagLimit).join(' ') || ''
  const fullText = `${title}\n\n${description}\n\n${hashtagString}`.trim()
  
  const encodedText = encodeURIComponent(fullText)
  const encodedUrl = encodeURIComponent(url)
  
  switch (platform) {
    case 'twitter':
      return `https://twitter.com/intent/tweet?text=${encodedText}&url=${encodedUrl}`
    
    case 'facebook':
      return `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}&quote=${encodeURIComponent(title)}`
    
    case 'linkedin':
      return `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}&title=${encodeURIComponent(title)}&summary=${encodeURIComponent(description)}`
    
    case 'instagram':
      // Instagram doesn't support direct URL sharing, return text for copy
      return fullText
    
    case 'tiktok':
      // TikTok doesn't support direct URL sharing, return text for copy
      return fullText
    
    default:
      return url
  }
}

// Generate Open Graph meta tags
export function generateOpenGraphTags(shareData: SocialShareData) {
  return {
    'og:title': shareData.title,
    'og:description': shareData.description,
    'og:url': shareData.url,
    'og:type': 'website',
    'og:site_name': 'Choices',
    'og:image': shareData.imageUrl || '/images/choices-social-preview.png',
    'og:image:width': '1200',
    'og:image:height': '630',
    'twitter:card': 'summary_large_image',
    'twitter:title': shareData.title,
    'twitter:description': shareData.description,
    'twitter:image': shareData.imageUrl || '/images/choices-social-preview.png',
    'twitter:site': '@ChoicesApp',
    'twitter:creator': '@ChoicesApp'
  }
}

// Generate share analytics tracking
export function generateShareTracking(shareData: SocialShareData, platform: string) {
  const trackingParams = new URLSearchParams({
    utm_source: platform,
    utm_medium: 'social',
    utm_campaign: 'viral_sharing',
    utm_content: shareData.title.substring(0, 50),
    ref: 'social_share'
  })
  
  return `${shareData.url}?${trackingParams.toString()}`
}

// Copy to clipboard with fallback
export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text)
      return true
    } else {
      // Fallback for older browsers
      const textArea = document.createElement('textarea')
      textArea.value = text
      textArea.style.position = 'fixed'
      textArea.style.left = '-999999px'
      textArea.style.top = '-999999px'
      document.body.appendChild(textArea)
      textArea.focus()
      textArea.select()
      const result = document.execCommand('copy')
      document.body.removeChild(textArea)
      return result
    }
  } catch (error) {
    console.error('Failed to copy to clipboard:', error)
    return false
  }
}

// Generate QR code data
export function generateQRCodeData(url: string): string {
  return `https://api.qrserver.com/v1/create-qr-code/?size=256x256&data=${encodeURIComponent(url)}`
}

// Social sharing analytics
export interface ShareAnalytics {
  platform: string
  contentType: 'poll' | 'civics'
  contentId: string
  timestamp: Date
  userId?: string
}

export function trackShare(analytics: ShareAnalytics) {
  // Send analytics to your tracking service
  if (typeof window !== 'undefined' && window.gtag) {
    window.gtag('event', 'share', {
      method: analytics.platform,
      content_type: analytics.contentType,
      item_id: analytics.contentId
    })
  }
  
  // Log for debugging
  console.log('Share tracked:', analytics)
}
