// No-op stub for client-only. Export nothing to avoid side effects.
module.exports = {};
