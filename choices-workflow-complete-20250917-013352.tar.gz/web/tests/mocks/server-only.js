// No-op stub for server-only. Export nothing to avoid side effects.
module.exports = {};
