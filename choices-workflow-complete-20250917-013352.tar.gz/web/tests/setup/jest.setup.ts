import '@testing-library/jest-dom';

// Optional: MSW for unit/integration tests
// import { server } from '../msw/server';
// beforeAll(() => server.listen());
// afterEach(() => server.resetHandlers());
// afterAll(() => server.close());
