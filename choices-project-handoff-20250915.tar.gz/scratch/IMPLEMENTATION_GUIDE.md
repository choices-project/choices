# 🚀 Implementation Guide - PWA + WebAuthn

**Date:** December 15, 2024  
**Status:** ✅ **READY FOR IMPLEMENTATION**  
**Target:** Complete PWA and WebAuthn MVP implementation

## 📋 **Quick Start Checklist**

### **Phase 1: Database Setup (30 minutes)**
- [ ] Run WebAuthn schema migration
- [ ] Verify tables and policies created
- [ ] Test RLS policies

### **Phase 2: PWA Implementation (1 hour)**
- [ ] Create PWA icons
- [ ] Add PWA install prompt to layout
- [ ] Test offline functionality
- [ ] Enable PWA feature flag

### **Phase 3: WebAuthn Implementation (2 hours)**
- [ ] Add WebAuthn UI components
- [ ] Integrate with existing auth
- [ ] Test on real devices
- [ ] Enable WebAuthn feature flag

## 🗄️ **Database Setup**

### **1. Run Migration**
```bash
# Connect to your Supabase database and run:
psql -h your-db-host -U postgres -d postgres -f scripts/migrations/001-webauthn-schema.sql
```

### **2. Verify Setup**
```sql
-- Check tables exist
\dt webauthn_*

-- Check policies
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual 
FROM pg_policies 
WHERE tablename LIKE 'webauthn_%';

-- Test functions
SELECT user_has_webauthn_credentials('your-user-id'::uuid);
```

## 🎨 **PWA Implementation**

### **1. Create PWA Icons**
```bash
# Create icons directory
mkdir -p public/icons

# You'll need these sizes:
# 72x72, 96x96, 128x128, 144x144, 152x152, 192x192, 384x384, 512x512
# Use your app logo and create these sizes
```

### **2. Add PWA Install Prompt**
```typescript
// In your main layout or app component
import { PWAInstallPrompt } from '@/lib/shared/pwa-components';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#3b82f6" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="Choices" />
        <link rel="apple-touch-icon" href="/icons/icon-192x192.png" />
      </head>
      <body>
        {children}
        <PWAInstallPrompt />
      </body>
    </html>
  );
}
```

### **3. Enable PWA Feature Flag**
```typescript
// In /lib/core/feature-flags.ts
export const FEATURE_FLAGS = {
  // ... other flags
  PWA: true, // Enable PWA features
} as const;
```

## 🔐 **WebAuthn Implementation**

### **1. Add WebAuthn UI Components**

#### **Registration Component**
```typescript
// Create /features/webauthn/components/BiometricSetup.tsx
'use client';

import { useState } from 'react';
import { isFeatureEnabled } from '@/lib/core/feature-flags';

export function BiometricSetup({ userId, username, displayName }: {
  userId: string;
  username: string;
  displayName: string;
}) {
  const [isSupported, setIsSupported] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);

  // Check WebAuthn support
  useEffect(() => {
    setIsSupported(
      typeof window !== 'undefined' &&
      window.PublicKeyCredential &&
      isFeatureEnabled('WEBAUTHN')
    );
  }, []);

  const handleRegister = async () => {
    if (!isSupported) return;
    
    setIsRegistering(true);
    try {
      // Call registration API
      const beginResponse = await fetch('/api/webauthn/register/begin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, username, displayName })
      });
      
      const options = await beginResponse.json();
      
      // Use WebAuthn API
      const credential = await navigator.credentials.create({
        publicKey: options
      });
      
      // Complete registration
      const completeResponse = await fetch('/api/webauthn/register/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, response: credential })
      });
      
      const result = await completeResponse.json();
      if (result.success) {
        alert('Passkey created successfully!');
      }
    } catch (error) {
      console.error('WebAuthn registration failed:', error);
      alert('Failed to create passkey');
    } finally {
      setIsRegistering(false);
    }
  };

  if (!isSupported) return null;

  return (
    <div className="p-4 border rounded-lg bg-blue-50">
      <h3 className="text-lg font-semibold mb-2">🔐 Create a Passkey</h3>
      <p className="text-sm text-gray-600 mb-4">
        Your fingerprint/face data never leaves your device. We store only a public key to verify it's really you.
      </p>
      <button
        onClick={handleRegister}
        disabled={isRegistering}
        className="px-4 py-2 bg-blue-500 text-white rounded-lg disabled:opacity-50"
      >
        {isRegistering ? 'Creating...' : 'Create Passkey'}
      </button>
    </div>
  );
}
```

#### **Login Component**
```typescript
// Create /features/webauthn/components/BiometricLogin.tsx
'use client';

import { useState } from 'react';
import { isFeatureEnabled } from '@/lib/core/feature-flags';

export function BiometricLogin({ userId }: { userId: string }) {
  const [isSupported, setIsSupported] = useState(false);
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  useEffect(() => {
    setIsSupported(
      typeof window !== 'undefined' &&
      window.PublicKeyCredential &&
      isFeatureEnabled('WEBAUTHN')
    );
  }, []);

  const handleLogin = async () => {
    if (!isSupported) return;
    
    setIsAuthenticating(true);
    try {
      // Call authentication API
      const beginResponse = await fetch('/api/webauthn/authenticate/begin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId })
      });
      
      const options = await beginResponse.json();
      
      // Use WebAuthn API
      const credential = await navigator.credentials.get({
        publicKey: options
      });
      
      // Complete authentication
      const completeResponse = await fetch('/api/webauthn/authenticate/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, response: credential })
      });
      
      const result = await completeResponse.json();
      if (result.success) {
        // Redirect or update auth state
        window.location.reload();
      }
    } catch (error) {
      console.error('WebAuthn authentication failed:', error);
      alert('Failed to authenticate with passkey');
    } finally {
      setIsAuthenticating(false);
    }
  };

  if (!isSupported) return null;

  return (
    <button
      onClick={handleLogin}
      disabled={isAuthenticating}
      className="w-full px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50"
    >
      {isAuthenticating ? 'Authenticating...' : '🔐 Sign in with Passkey'}
    </button>
  );
}
```

### **2. Integrate with Existing Auth**

#### **Add to Login Page**
```typescript
// In your login page
import { BiometricLogin } from '@/features/webauthn/components/BiometricLogin';

export default function LoginPage() {
  const [userId, setUserId] = useState('');

  return (
    <div>
      {/* Existing login form */}
      
      {/* WebAuthn login */}
      {userId && <BiometricLogin userId={userId} />}
    </div>
  );
}
```

#### **Add to User Dashboard**
```typescript
// In your user dashboard
import { BiometricSetup } from '@/features/webauthn/components/BiometricSetup';

export default function UserDashboard() {
  const { user } = useAuth();

  return (
    <div>
      {/* Existing dashboard content */}
      
      {/* WebAuthn setup */}
      <BiometricSetup 
        userId={user.id}
        username={user.email}
        displayName={user.user_metadata?.full_name || user.email}
      />
    </div>
  );
}
```

### **3. Enable WebAuthn Feature Flag**
```typescript
// In /lib/core/feature-flags.ts
export const FEATURE_FLAGS = {
  // ... other flags
  WEBAUTHN: 'pilot', // Start with pilot mode
} as const;
```

## 🧪 **Testing**

### **PWA Testing**
```bash
# 1. Build and serve the app
npm run build
npx serve -s out -l 3000

# 2. Open in browser and check:
# - DevTools > Application > Manifest (should show PWA manifest)
# - DevTools > Application > Service Workers (should show registered SW)
# - DevTools > Network > Offline (test offline functionality)

# 3. Test install prompt:
# - Look for install button in address bar
# - Test "Add to Home Screen" on mobile
```

### **WebAuthn Testing**
```bash
# 1. Test on real devices:
# - iPhone with Face ID
# - Android with fingerprint
# - MacBook with Touch ID
# - Windows with Windows Hello

# 2. Test fallbacks:
# - Browsers without WebAuthn support
# - Devices without biometrics

# 3. Test error cases:
# - Invalid credentials
# - Expired challenges
# - Network failures
```

## 🚨 **Common Issues & Solutions**

### **PWA Issues**
- **Manifest not loading:** Check file path and MIME type
- **Service worker not registering:** Check console for errors
- **Offline page not showing:** Verify offline.html exists

### **WebAuthn Issues**
- **"Not supported" error:** Check browser compatibility
- **"Invalid credential" error:** Verify database schema
- **"Challenge expired" error:** Check challenge TTL

### **Database Issues**
- **RLS policy errors:** Verify user authentication
- **Permission denied:** Check function permissions
- **Table not found:** Run migration script

## 📊 **Monitoring & Metrics**

### **PWA Metrics**
```typescript
// Add to your analytics
const pwaMetrics = {
  installPromptShown: 0,
  installPromptAccepted: 0,
  offlineUsage: 0,
  serviceWorkerErrors: 0
};
```

### **WebAuthn Metrics**
```typescript
// Add to your analytics
const webauthnMetrics = {
  registrationAttempts: 0,
  registrationSuccess: 0,
  authenticationAttempts: 0,
  authenticationSuccess: 0,
  fallbackUsage: 0
};
```

## 🎯 **Success Criteria**

### **PWA Success**
- [ ] App installs on mobile devices
- [ ] Offline functionality works
- [ ] Service worker caches properly
- [ ] Install prompt appears

### **WebAuthn Success**
- [ ] Users can create passkeys
- [ ] Users can authenticate with passkeys
- [ ] Fallbacks work for unsupported devices
- [ ] No biometric data stored server-side

## 🚀 **Deployment Checklist**

### **Pre-deployment**
- [ ] Database migration run
- [ ] Feature flags configured
- [ ] Icons created and uploaded
- [ ] Service worker tested
- [ ] WebAuthn tested on real devices

### **Post-deployment**
- [ ] Monitor error rates
- [ ] Check user adoption metrics
- [ ] Verify offline functionality
- [ ] Test on various devices

---

**Status:** ✅ **READY FOR IMPLEMENTATION**  
**Estimated Time:** 3-4 hours total  
**Priority:** PWA first, then WebAuthn  
**Confidence:** High - All code and infrastructure ready
