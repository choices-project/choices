module.exports = {
  extends: [
    "next/core-web-vitals"
  ],
  plugins: ["unused-imports"],
  overrides: [
    {
      files: ["**/*.{ts,tsx}"],
      parser: "@typescript-eslint/parser",
      plugins: ["@typescript-eslint"],
      rules: {
        "no-unused-vars": "off",
        "@typescript-eslint/no-unused-vars": [
          "warn",
          {
            "args": "all",
            "argsIgnorePattern": "^_",
            "varsIgnorePattern": "^_",
            "caughtErrors": "all",
            "caughtErrorsIgnorePattern": "^_"
          }
        ]
      }
    },
    {
      files: ["**/*.{js,jsx}"],
      rules: {
        "no-unused-vars": ["warn", { 
          "argsIgnorePattern": "^_",
          "varsIgnorePattern": "^_",
          "caughtErrorsIgnorePattern": "^_"
        }]
      }
    }
  ],
  rules: {
    "no-console": ["warn", { "allow": ["warn", "error"] }],
    "react/no-unescaped-entities": "off",
    "@next/next/no-img-element": "warn",
    "react-hooks/exhaustive-deps": "warn",
    "prefer-const": "warn",
    "unused-imports/no-unused-imports": "error"
  }
};
