export async function prove(_: unknown) { return { proof: 'stub' }; }
export async function verify(_: unknown) { return true; }






